-- AlterTable
ALTER TABLE `Project` MODIFY `ds_project` VARCHAR(350) NOT NULL;
